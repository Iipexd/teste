# Projeto The Forgotten Server (TFS) 1.6 Dockerizado

Este projeto fornece uma estrutura Docker completa e configurada para executar o The Forgotten Server (TFS) 1.6, juntamente com um banco de dados MySQL e phpMyAdmin para gerenciamento.

## Visão Geral

O objetivo deste projeto é simplificar a instalação e o gerenciamento de um servidor TFS 1.6, utilizando containers Docker para isolar e orquestrar os serviços necessários. A estrutura inclui:

*   **The Forgotten Server (TFS):** O emulador do servidor de jogo.
*   **MySQL:** O banco de dados para armazenar dados do jogo.
*   **phpMyAdmin:** Uma interface web para gerenciar o banco de dados MySQL.
*   **Scripts de Gerenciamento:** Scripts para iniciar, parar, reiniciar e fazer backup do servidor.

Este setup foi pensado para funcionar corretamente no Windows Subsystem for Linux (WSL) com Ubuntu 22.04, permitindo acesso aos serviços a partir do Windows.

## Pré-requisitos

Antes de começar, certifique-se de ter os seguintes softwares instalados em seu sistema (WSL Ubuntu 22.04):

*   **Docker:** [Instruções de instalação do Docker Engine no Ubuntu](https://docs.docker.com/engine/install/ubuntu/)
*   **Docker Compose:** Geralmente instalado junto com o Docker Engine. Se não, [Instruções de instalação do Docker Compose](https://docs.docker.com/compose/install/)

Certifique-se de que o Docker Desktop esteja configurado para usar o backend do WSL 2 se você estiver gerenciando o Docker a partir do Windows.

## Estrutura de Diretórios do Projeto

```
/home/ubuntu/tfs_project/
├── Dockerfile                # Define a imagem Docker para o TFS
├── docker-compose.yml        # Orquestra os containers (TFS, MySQL, phpMyAdmin)
├── config/                   # Arquivos de configuração
│   └── config.lua            # Configuração principal do TFS (montado no container)
├── data/
│   ├── init.sql              # Schema inicial do banco de dados (usado na primeira execução do MySQL)
│   └── backup/               # Diretório onde os backups do banco de dados serão salvos
├── scripts/
│   ├── start.sh              # Script para iniciar todos os serviços
│   ├── stop.sh               # Script para parar todos os serviços
│   ├── restart.sh            # Script para reiniciar todos os serviços
│   └── backup.sh             # Script para fazer backup do banco de dados
└── README.md                 # Este arquivo de documentação
```

**Observações:**
*   O diretório `db_data` (para dados persistentes do MySQL) e `tfs_data` (para dados persistentes do TFS, como o mapa) serão criados automaticamente pelo Docker Compose na primeira vez que os serviços forem iniciados, dentro de `/home/ubuntu/tfs_project/`.

## Configuração Inicial

1.  **Clone o Repositório (ou copie os arquivos):**
    Se este projeto estiver em um repositório Git, clone-o. Caso contrário, copie todos os arquivos e diretórios para `/home/ubuntu/tfs_project/` no seu WSL.

2.  **Revise `config/config.lua`:**
    O arquivo `config/config.lua` fornecido contém configurações básicas. Você pode precisar ajustá-lo conforme suas necessidades específicas (por exemplo, `serverName`, `worldType`, taxas, etc.). As configurações de conexão com o banco de dados (`mysqlHost`, `mysqlUser`, `mysqlPass`, `mysqlDatabase`) já estão definidas para funcionar com o container MySQL definido no `docker-compose.yml`.

3.  **Revise `data/init.sql`:**
    O arquivo `data/init.sql` é usado para inicializar o banco de dados na primeira vez que o container MySQL é criado. Ele deve conter o schema SQL completo do The Forgotten Server 1.6. O arquivo fornecido é um placeholder ou um schema básico. **É crucial substituí-lo pelo schema SQL oficial e completo do TFS 1.6** (geralmente encontrado no repositório oficial do TFS, como `data/schema.sql` ou `schemas/mysql.sql`).

4.  **Permissões dos Scripts:**
    Certifique-se de que os scripts no diretório `scripts/` tenham permissão de execução:
    ```bash
    cd /home/ubuntu/tfs_project
    chmod +x scripts/*.sh
    ```

## Como Construir e Executar

Para iniciar todos os serviços (TFS, MySQL, phpMyAdmin):

1.  Navegue até o diretório raiz do projeto no seu terminal WSL:
    ```bash
    cd /home/ubuntu/tfs_project
    ```

2.  Execute o script `start.sh`:
    ```bash
    ./scripts/start.sh
    ```
    Este comando irá construir a imagem Docker do TFS (se ainda não construída) e iniciar todos os containers em modo detached (`-d`).

    Na primeira vez, a construção da imagem do TFS pode levar alguns minutos, pois irá compilar o servidor a partir do código-fonte.

## Acessando os Serviços

*   **The Forgotten Server (TFS):**
    *   O servidor estará escutando nas portas `7171` (login) e `7172` (game) do seu WSL.
    *   Para conectar com um cliente Tibia, use o endereço IP do seu WSL. Você pode encontrá-lo no WSL com o comando `ip addr show eth0 | grep 'inet ' | awk '{print $2}' | cut -d/ -f1` ou, se estiver usando o Docker Desktop com WSL backend, geralmente `localhost` a partir do Windows também funciona.

*   **phpMyAdmin:**
    *   Acesse via navegador no Windows ou WSL em: `http://localhost:8080`
    *   **Servidor:** `db` (este é o nome do serviço do container MySQL no `docker-compose.yml`)
    *   **Usuário:** `root`
    *   **Senha:** `root_password` (conforme definido em `docker-compose.yml`)
    Você também pode usar o usuário `tfsuser` com a senha `tfspassword` para acessar especificamente o banco de dados `theforgottenserver`.

## Gerenciando os Serviços

Os seguintes scripts estão disponíveis no diretório `scripts/` para facilitar o gerenciamento:

*   **Iniciar os serviços:**
    ```bash
    ./scripts/start.sh
    ```

*   **Parar os serviços:**
    ```bash
    ./scripts/stop.sh
    ```
    Este comando para e remove os containers.

*   **Reiniciar os serviços:**
    ```bash
    ./scripts/restart.sh
    ```
    Este comando para os containers e os inicia novamente.

*   **Ver logs dos containers:**
    Para ver os logs do servidor TFS:
    ```bash
    docker logs tfs_server
    ```
    Para ver os logs do MySQL:
    ```bash
    docker logs tfs_db
    ```
    Para ver todos os logs definidos no `docker-compose.yml`:
    ```bash
    docker-compose logs -f
    ```
    Ou para um serviço específico:
    ```bash
    docker-compose logs -f tfs
    docker-compose logs -f db
    ```

*   **Acessar o console do container TFS:**
    ```bash
    docker exec -it tfs_server bash
    ```
    Dentro do container, o servidor TFS está localizado em `/app/forgottenserver/` e o executável em `/app/forgottenserver/build/tfs`.

## Backup e Restauração do Banco de Dados

### Backup

O script `scripts/backup.sh` foi criado para facilitar o backup do banco de dados MySQL.

Para fazer um backup:

1.  Certifique-se de que os containers estejam em execução.
2.  Execute o script:
    ```bash
    ./scripts/backup.sh
    ```
    Isso criará um arquivo `.sql.gz` compactado no diretório `data/backup/` com um timestamp no nome (ex: `backup_YYYYMMDD_HHMMSS.sql.gz`).

**Importante sobre Backups Automáticos:**
O pedido original incluía backups automáticos a cada 5 horas. No entanto, este ambiente não implementa agendamento automático de tarefas (como cron jobs dentro do container de forma persistente e gerenciável por este setup). Você precisará executar o script de backup manualmente ou configurar um agendador de tarefas no seu sistema WSL (host) para executar o script `scripts/backup.sh` periodicamente.

Exemplo de como adicionar ao crontab do WSL para rodar a cada 5 horas (execute `crontab -e` no WSL e adicione a linha):
```cron
0 */5 * * * /home/ubuntu/tfs_project/scripts/backup.sh >> /home/ubuntu/tfs_project/data/backup/cron.log 2>&1
```
Lembre-se que o WSL precisa estar em execução para o cron job funcionar.

### Restauração

Para restaurar o banco de dados a partir de um arquivo de backup:

1.  **Pare os serviços** se estiverem em execução para evitar inconsistências:
    ```bash
    ./scripts/stop.sh
    ```
2.  **Inicie apenas o container do banco de dados** (se você parou todos os serviços):
    ```bash
    docker-compose up -d db
    ```
    Aguarde alguns segundos para o MySQL iniciar completamente.

3.  **Importe o backup.** Se o seu backup for um arquivo `.sql.gz`, primeiro descompacte-o:
    ```bash
    gunzip -c /home/ubuntu/tfs_project/data/backup/NOME_DO_SEU_BACKUP.sql.gz | docker exec -i tfs_db mysql -u root -proot_password theforgottenserver
    ```
    Substitua `NOME_DO_SEU_BACKUP.sql.gz` pelo nome real do seu arquivo de backup.
    Se o backup for um arquivo `.sql` não compactado:
    ```bash
    cat /home/ubuntu/tfs_project/data/backup/NOME_DO_SEU_BACKUP.sql | docker exec -i tfs_db mysql -u root -proot_password theforgottenserver
    ```

4.  Após a restauração bem-sucedida, você pode **iniciar todos os serviços** novamente:
    ```bash
    ./scripts/start.sh
    ```

## Configurações Adicionais

*   **`config.lua`:** Este é o arquivo principal de configuração do TFS. Ele é montado a partir de `./config/config.lua` no host para o container do TFS. Qualquer alteração neste arquivo no host exigirá um reinício do container do TFS para ter efeito (`./scripts/restart.sh` ou pare e inicie apenas o serviço `tfs` com `docker-compose restart tfs`).
*   **Variáveis de Ambiente do MySQL:** As credenciais do MySQL (usuário root, usuário da aplicação, nome do banco) são definidas na seção `environment` do serviço `db` no arquivo `docker-compose.yml`.
*   **Portas:** As portas do TFS (7171, 7172) e do phpMyAdmin (8080) são mapeadas para o host. Se precisar alterar, modifique a seção `ports` no `docker-compose.yml`.

## Reinício Automático do Servidor TFS

O Docker Compose está configurado com `restart: always` para os serviços `tfs`, `db` e `phpmyadmin`. Isso significa que se um container parar inesperadamente (por exemplo, devido a um erro no TFS ou no MySQL), o Docker tentará reiniciá-lo automaticamente.

O script `./build/tfs` dentro do container do TFS é o executável do servidor. Se ele falhar, o Docker reiniciará o container `tfs_server`.

## Considerações sobre WSL

*   **Acesso de Rede:** Ao rodar no WSL 2, os containers Docker são acessíveis a partir do Windows usando `localhost` para as portas mapeadas (ex: `http://localhost:8080` para phpMyAdmin). Se `localhost` não funcionar, você pode precisar usar o endereço IP específico da sua interface WSL. Você pode obter o IP do WSL executando `hostname -I` ou `ip a | grep eth0` dentro do terminal WSL.
*   **Recursos:** Certifique-se de que seu WSL tenha recursos suficientes (CPU, memória) alocados no Docker Desktop (se aplicável) ou nas configurações do WSL para rodar os containers de forma suave.
*   **Persistência de Dados:** Os dados do MySQL são persistidos no volume `db_data` e os dados do TFS (como mapa e arquivos de jogadores, se configurado para salvar fora do banco) no volume `tfs_data`. Esses volumes são mapeados para subdiretórios dentro do diretório do projeto no sistema de arquivos do WSL, garantindo que os dados não sejam perdidos quando os containers são parados ou recriados.

## Atualizando o The Forgotten Server

Para atualizar o TFS para uma versão mais recente (assumindo que as alterações estão no branch `master` do repositório oficial ou no branch que você está usando):

1.  Pare os serviços:
    ```bash
    ./scripts/stop.sh
    ```
2.  Reconstrua a imagem do TFS sem usar cache para garantir que o código mais recente seja baixado e compilado:
    ```bash
    docker-compose build --no-cache tfs
    ```
3.  Inicie os serviços novamente:
    ```bash
    ./scripts/start.sh
    ```
    **Nota:** Atualizações do TFS podem exigir alterações no schema do banco de dados. Consulte a documentação oficial do TFS para quaisquer etapas de migração de banco de dados necessárias após uma atualização.

## Comandos Docker Úteis

*   Listar containers em execução: `docker ps`
*   Listar todos os containers (incluindo parados): `docker ps -a`
*   Listar imagens Docker: `docker images`
*   Parar um container específico: `docker stop <nome_do_container_ou_id>` (ex: `docker stop tfs_server`)
*   Iniciar um container parado: `docker start <nome_do_container_ou_id>`
*   Remover um container parado: `docker rm <nome_do_container_ou_id>`
*   Remover uma imagem: `docker rmi <nome_da_imagem_ou_id>`
*   Verificar o uso de recursos dos containers: `docker stats`

## Comandos Ubuntu Úteis (dentro do WSL)

*   Verificar o status do serviço Docker: `sudo systemctl status docker` (ou `service docker status`)
*   Navegar no sistema de arquivos: `cd`, `ls`, `pwd`
*   Editar arquivos: `nano`, `vim` (ex: `nano config/config.lua`)
*   Verificar uso de disco: `df -h`
*   Verificar uso de memória: `free -h`
*   Verificar processos: `top`, `htop`

## Sincronizando com um Repositório GitHub

Para manter este projeto em um repositório GitHub:

1.  Crie um novo repositório no GitHub.
2.  No diretório do projeto (`/home/ubuntu/tfs_project`) no seu WSL, inicialize um repositório Git:
    ```bash
    git init
    git add .
    git commit -m "Commit inicial do projeto TFS Dockerizado"
    ```
3.  Adicione o repositório remoto do GitHub:
    ```bash
    git remote add origin URL_DO_SEU_REPOSITORIO_GITHUB.git
    ```
    Substitua `URL_DO_SEU_REPOSITORIO_GITHUB.git` pela URL fornecida pelo GitHub.
4.  Envie seus arquivos para o GitHub:
    ```bash
    git push -u origin master  # ou main, dependendo do nome do seu branch padrão
    ```

Posteriormente, para enviar atualizações:
```bash
git add .
git commit -m "Sua mensagem de commit"
git push
```
Para baixar atualizações de outros colaboradores (se houver):
```bash
git pull
```

## Solução de Problemas Comuns

*   **Erro de Permissão ao executar scripts:** Certifique-se de que os scripts em `scripts/` tenham permissão de execução (`chmod +x scripts/*.sh`).
*   **Portas já em uso:** Se você receber um erro informando que uma porta já está em uso, verifique se outro serviço não está usando essa porta no seu WSL ou Windows. Você pode alterar as portas mapeadas no `docker-compose.yml`.
*   **Falha na compilação do TFS (Dockerfile):** Verifique os logs de construção (`docker-compose build tfs`). Pode ser devido a dependências ausentes (embora o Dockerfile tente instalar todas) ou problemas de rede ao clonar o repositório do TFS.
*   **TFS não conecta ao banco de dados:**
    *   Verifique se o container `tfs_db` está em execução (`docker ps`).
    *   Verifique os logs do container `tfs_db` para erros do MySQL.
    *   Confirme se as credenciais e o nome do host do banco de dados em `config/config.lua` (`mysqlHost = "db"`, `mysqlUser`, `mysqlPass`, `mysqlDatabase`) correspondem às definidas no `docker-compose.yml` para o serviço `db`.
*   **phpMyAdmin não conecta:**
    *   Certifique-se de que o container `tfs_db` esteja em execução.
    *   Verifique se você está usando `db` como o nome do servidor no login do phpMyAdmin.
    *   Confirme as credenciais `PMA_USER` e `PMA_PASSWORD` no `docker-compose.yml` (para o usuário root do MySQL).

---

Este projeto visa fornecer uma base sólida e fácil de usar para seu servidor The Forgotten Server 1.6. Sinta-se à vontade para adaptá-lo e expandi-lo conforme suas necessidades!

