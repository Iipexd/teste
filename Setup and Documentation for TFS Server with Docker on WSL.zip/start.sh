#!/bin/bash
# Start script for TFS Docker containers
# This script starts the Docker containers defined in docker-compose.yml in detached mode.

cd /home/ubuntu/tfs_project

echo "Starting TFS Docker containers..."
docker-compose up -d

if [ $? -eq 0 ]; then
  echo "TFS Docker containers started successfully."
  echo "You can access phpMyAdmin at http://localhost:8080 (or your WSL IP if accessing from Windows)"
  echo "The Forgotten Server should be accessible on ports 7171 and 7172."
else
  echo "Error starting TFS Docker containers. Check logs using: docker-compose logs"
fi

