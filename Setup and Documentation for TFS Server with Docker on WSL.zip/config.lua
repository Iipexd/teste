-- MySQL Hostname
mysqlHost = "db"
-- MySQL Port (default: 3306)
mysqlPort = 3306
-- MySQL Username
mysqlUser = "tfsuser"
-- MySQL Password
mysqlPass = "tfspassword"
-- MySQL Database Name
mysqlDatabase = "theforgottenserver"
-- MySQL Socket (leave empty for TCP/IP)
mysqlSock = ""
-- MySQL SSL (true or false)
mysqlSSL = false

-- Server Name
serverName = "MyTFS Server"
-- IP Address (leave "auto" for auto-detection)
ip = "127.0.0.1" -- This will be the container's IP, but Docker handles mapping
-- Login Port (default: 7171)
loginPort = 7171
-- Game Port (default: 7172)
gamePort = 7172
-- Status Port (default: 7171, usually same as login)
statusPort = 7171

-- World Type (pvp, no-pvp, pvp-enforced)
worldType = "pvp"
-- MOTD (Message of the Day)
motd = "Welcome to The Forgotten Server!"

-- Other settings can be added or modified as needed based on TFS documentation
-- For example, map settings, rates, etc.
mapName = "forgotten"
mapAuthor = "Unknown"

-- Datapack location (relative to the server executable)
dataDirectory = "data/"

-- Enable house auctions (true or false)
houseAuctions = true

-- Enable market (true or false)
marketEnabled = true

-- SQL type (mysql or sqlite)
sqlType = "mysql"

-- Automatic broadcast messages
-- broadcastMessages = {
--   {interval = 60, message = "Don't forget to visit our website!"},
--   {interval = 120, message = "Report bugs using /bug command."}
-- }

-- For TFS 1.4+ (including 1.6), ensure all necessary settings are present.
-- Refer to the latest config.lua.dist from the otland/forgottenserver repository for a full list.
-- This is a basic configuration to get started.

-- Login protocol port (used by login server)
loginProtocolPort = 7171

-- Game protocol port (used by game server)
gameProtocolPort = 7172

-- Admin protocol port (used by OTAdmin)
adminProtocolPort = 7171

-- Status protocol port (used by server status)
statusProtocolPort = 7171

-- Use this to bind the service to a specific IP address, usually not needed with Docker
-- bindOnlyGlobalAddress = false

-- For client 12+ (TFS 1.4+)
-- features = {
--     [Features.LoginServer] = true,
--     [Features.GameServer] = true,
--     [Features.ManagementServer] = true,
--     [Features.StatusServer] = true
-- }

-- RSA key for encryption
rsaKey = "data/rsa_key.pem"

-- Client version limits
-- minClientVersion = "10.00"
-- maxClientVersion = "12.91"

-- Other important settings from a typical config.lua.dist
-- worldId = 0
-- onePlayerOnlinePerAccount = true
-- allowClones = false
-- serverSaveEnabled = true
-- serverSaveNotifyMessage = true
-- serverSaveNotifyDuration = 10
-- serverSaveShutdown = false
-- cleanProtectionZones = true
-- housePriceEachSQM = 50
-- houseRentPeriod = "month"
-- premiumToCreateGuild = true
-- guildNameMinLength = 3
-- guildNameMaxLength = 30
-- highscoresEnabled = true
-- storeImagesUrl = "http://localhost/store_images/"
-- marketOfferDuration = 30
-- marketOfferPremiumDuration = 90
-- freePremium = false
-- premiumForPromotion = true
-- levelToBuyHouse = 20
-- dataOpcodes = "data/opcodes.json"

