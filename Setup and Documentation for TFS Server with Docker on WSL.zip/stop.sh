#!/bin/bash
# Stop script for TFS Docker containers
# This script stops the Docker containers defined in docker-compose.yml.

cd /home/ubuntu/tfs_project

echo "Stopping TFS Docker containers..."
docker-compose down

if [ $? -eq 0 ]; then
  echo "TFS Docker containers stopped successfully."
else
  echo "Error stopping TFS Docker containers. Check logs if they were running."
fi

