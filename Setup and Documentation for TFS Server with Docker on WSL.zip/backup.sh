#!/bin/bash
# Backup script for TFS MySQL database
# Este script cria um backup do banco de dados MySQL usado pela aplicação TFS.
# Ele salva o backup no diretório /home/ubuntu/tfs_project/data/backup com um timestamp.

# Credenciais do Banco de Dados (conforme definido no docker-compose.yml)
DB_USER="tfsuser"
DB_PASS="tfspassword"
DB_NAME="theforgottenserver"
DB_CONTAINER_NAME="tfs_db" # Nome do container do banco de dados

# Diretório de Backup dentro do diretório do projeto
BACKUP_DIR_HOST="./data/backup"

# Cria o diretório de backup no host se não existir
mkdir -p "$(pwd)/$BACKUP_DIR_HOST"

# Nome do arquivo com timestamp
FILENAME_HOST="$(pwd)/$BACKUP_DIR_HOST/backup_$(date +%Y%m%d_%H%M%S).sql.gz"

# Comando para fazer o dump do banco de dados e comprimir
echo "Iniciando backup do banco de dados $DB_NAME do container $DB_CONTAINER_NAME..."
docker exec "$DB_CONTAINER_NAME" sh -c "exec mysqldump -u'$DB_USER' -p'$DB_PASS' '$DB_NAME'" | gzip > "$FILENAME_HOST"

# Verifica se o backup foi bem-sucedido
if [ $? -eq 0 ]; then
  echo "Backup concluído com sucesso: $FILENAME_HOST"
else
  echo "Erro ao criar o backup do banco de dados."
  exit 1
fi

# (Opcional) Remover backups mais antigos que X dias
# find "$(pwd)/$BACKUP_DIR_HOST" -name "backup_*.sql.gz" -type f -mtime +7 -delete
# echo "Backups com mais de 7 dias foram removidos."

echo "Script de backup finalizado."

